#' @title phenotype
#'
#' @description
#' phenotype matrix which is example data from R package GAPIT
#'
#' @docType data
#' @keywords datasets
#' @name phenotype
#'
#' @param phenotype a matrix
#'
#' @source R package GAPIT
NULL
