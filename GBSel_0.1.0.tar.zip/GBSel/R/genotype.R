#' @title genotype
#'
#' @description
#' genotype matrix which is example data from R package GAPIT
#'
#' @docType data
#' @keywords datasets
#' @name genotype
#'
#' @param genotype a matrix
#'
#' @source R package GAPIT
NULL
